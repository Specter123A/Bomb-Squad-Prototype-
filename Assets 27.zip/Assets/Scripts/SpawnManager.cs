using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnManager : MonoBehaviour
{
    //Initialize fields in the inspecter
    [SerializeField]
    private GameObject enemyPre;

    [SerializeField]
    private GameObject enemyPre1;

     [SerializeField]
    private float enemyPreInterval = 4.5f;

     [SerializeField]
    private float enemyPre1Interval= 2.5f;




// Start is called before the first frame update
    void Start()
    {
        StartCoroutine(spawnEnemy(enemyPreInterval, enemyPre));
        StartCoroutine(spawnEnemy(enemyPre1Interval, enemyPre1));
    }

    private IEnumerator spawnEnemy(float interval, GameObject enemy)
    {
        yield return new WaitForSeconds(interval);
        GameObject newEnemy = Instantiate(enemyPre, new Vector3(Random.Range(-2f,6), Random.Range(-2f, 6), 0), Quaternion.identity);
        StartCoroutine(spawnEnemy(interval, enemy));
    }


}
